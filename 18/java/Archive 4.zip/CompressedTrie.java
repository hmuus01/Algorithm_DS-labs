import java.util.Map;
import java.util.*;

public class CompressedTrie {
    public Map<String, CompressedTrie> children;

    public CompressedTrie() {
        System.out.println("Constructing new Trie");
         children = new HashMap<String, CompressedTrie>();
    }
    public static CompressedTrie compressTrie(Trie t) {
        if(t == null)
            return null;
        CompressedTrie c = new CompressedTrie();
        
        String prefix = "";
        for(int i =0; i<t.children.length;i++)
        {
            if(t.children[i] !=null)
            {
                prefix = "" + (char)('a'+i);
                //System.out.println(prefix);
                Trie child;
                child = t.children[i];            
            if(counter(child) == 1)
            {
                
                do{
                     prefix += "" + (char)('a'+onlyOneChild(child));
                    child = child.children[onlyOneChild(child)];
                }while(counter(child)==1);
            }
                c.children.put(prefix,compressTrie(child));
            }
        }
        System.out.println(prefix);
        // do{
        //             prefix += "" + (char)('a'+onlyOneChild(child));
        //             if(counter(t)==0)
        //                 break;
        //             child = child.children[onlyOneChild(child)];
        //     }while(onlyOneChild(child)==1);
        return c;
	//return new CompressedTrie();
    }
    public static int counter(Trie t)
    {
        int count = 0;
        for(int i=0;i<t.children.length;i++)
        {   
            if(t.children[i] != null)
            {
                count++;
            }
        }
        return count;
    }
    public static int onlyOneChild(Trie t)
    {
        for(int i=0; i<t.children.length; i++)
        {
            if(t.children[i] != null)
            {
                return i;
            }
        }
        return 0;
    }
    public boolean query(String s) {
	return false;
    }
    public void insert(String s) {
    }
}
