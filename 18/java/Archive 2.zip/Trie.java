import java.util.*;
import java.io.*;
public class Trie {
    public Trie[] children;
    public Trie() {
    	children = new Trie[27];
    }
    public void insert(String s)throws IOException {
    	//for(int j =0; j< s.length; j++)
    	//{
    	if(s.length() == 0)
    		children[26] = new Trie();
    	else
    	{
    		int indx =s.charAt(0) - 'a';
    		if(children[indx] == null)
    			children[indx]= new Trie();

    		children[indx].insert(s.substring(1));
    	}
    	//}
    }
    public boolean query(String s)throws IOException {
    	// int indx = s.charAt(0) - 'a';
    	if(s.length() == 0)
    	{
    		if(children[26]==null)
    			return false;
    		else
    			return true;
    	}
    	else
    		{
    			int indx = s.charAt(0) - 'a';
    			if(children[indx]== null)
    			{
    			System.out.println("not found");
    			return false;
    			}
    			else
    			{
    				return children[indx].query(s.substring(1));
    			}
    		}

    	
    }
    public static void main(String args[])
    {
  //   	Trie t = new Trie();
		// t.insert("one");
		// t.insert("two");
		// t.query("ones");
		// t.query("two");

    }
}
