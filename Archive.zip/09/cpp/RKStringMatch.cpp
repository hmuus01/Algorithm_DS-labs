#include "RKStringMatch.hpp"

size_t RKStringMatch::match(std::string text, std::string pattern) {
  return -1;
}
