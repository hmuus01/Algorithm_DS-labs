#include "NaiveStringMatch.hpp"

size_t NaiveStringMatch::match(std::string text, std::string pattern) {
  return -1;
}
