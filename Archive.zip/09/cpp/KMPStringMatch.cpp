#include "KMPStringMatch.hpp"

size_t KMPStringMatch::match(std::string text, std::string pattern) {
  return -1;
}
