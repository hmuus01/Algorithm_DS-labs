#include "SLList.hpp"
#include "ListVisualiser.hpp"

ListVisualiser::ListVisualiser(SLList *a) {
}

void ListVisualiser::visualise() {  
}
