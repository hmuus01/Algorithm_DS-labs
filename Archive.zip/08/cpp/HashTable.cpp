#include "HashTable.hpp"

HashTable::HashTable(long _a, long _c, long _m) {
}

HashTable::~HashTable() {
}

void HashTable::insert(int key) {
}

bool HashTable::find(int key) {
  return false;
}

double HashTable::loadFactor() {
  return 0.0;
}
